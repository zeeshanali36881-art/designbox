
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onAddToCart: (p: Product) => void;
  onAddToWishlist: (p: Product) => void;
  isWishlisted: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onAddToCart, onAddToWishlist, isWishlisted }) => {
  return (
    <div className="group relative">
      <div className="relative aspect-[4/5] bg-gray-100 rounded-3xl overflow-hidden mb-4">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" 
        />
        
        {/* Hover Actions */}
        <div className="absolute inset-0 bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="absolute bottom-4 left-4 right-4 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
            <button 
              onClick={() => onAddToCart(product)}
              className="w-full bg-white text-black py-3 rounded-xl font-bold text-sm shadow-xl hover:bg-black hover:text-white transition-all flex items-center justify-center gap-2"
            >
              <i className="fa-solid fa-cart-plus"></i>
              Add to Cart
            </button>
          </div>
        </div>

        {/* Wishlist Button */}
        <button 
          onClick={() => onAddToWishlist(product)}
          className={`absolute top-4 right-4 w-10 h-10 rounded-full flex items-center justify-center transition-all ${
            isWishlisted ? 'bg-red-500 text-white' : 'bg-white/80 text-black hover:bg-white'
          }`}
        >
          <i className={`${isWishlisted ? 'fa-solid' : 'fa-regular'} fa-heart`}></i>
        </button>
      </div>

      <div className="px-1">
        <div className="flex justify-between items-start mb-1">
          <h3 className="font-bold text-lg leading-tight group-hover:text-gray-700 transition-colors">{product.name}</h3>
          <span className="font-black text-lg">${product.price.toFixed(2)}</span>
        </div>
        <p className="text-gray-400 text-xs uppercase tracking-widest font-bold mb-2">{product.category}</p>
        <div className="flex items-center gap-1 text-xs">
          <div className="flex text-yellow-400">
            {[...Array(5)].map((_, i) => (
              <i key={i} className={`fa-solid fa-star ${i >= Math.floor(product.rating) ? 'text-gray-200' : ''}`}></i>
            ))}
          </div>
          <span className="text-gray-500 font-medium">({product.rating})</span>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
