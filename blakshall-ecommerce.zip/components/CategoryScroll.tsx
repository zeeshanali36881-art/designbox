
import React from 'react';
import { CATEGORIES } from '../constants.tsx';

const CategoryScroll: React.FC = () => {
  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="text-3xl font-black uppercase tracking-tighter">Shop by Category</h2>
            <div className="h-1 w-12 bg-black mt-1"></div>
          </div>
          <button className="text-sm font-bold border-b-2 border-black hover:opacity-70 transition-opacity">
            View All
          </button>
        </div>

        {/* Mobile View: 3 items per row, horizontal scroll */}
        <div className="flex overflow-x-auto gap-4 no-scrollbar snap-x snap-mandatory">
          {CATEGORIES.map((cat) => (
            <div 
              key={cat.id} 
              className="flex-shrink-0 w-[calc(33.333%-11px)] md:w-44 group cursor-pointer snap-start"
            >
              <div className="relative aspect-square rounded-2xl overflow-hidden mb-3 bg-gray-100">
                <img 
                  src={cat.image} 
                  alt={cat.name} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all"></div>
              </div>
              <p className="text-center font-bold text-xs md:text-sm uppercase tracking-wider group-hover:text-gray-600 transition-colors">
                {cat.name}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryScroll;
