
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { getAiSearchSuggestions } from '../services/gemini';

interface NavbarProps {
  cartCount: number;
  wishlistCount: number;
}

const Navbar: React.FC<NavbarProps> = ({ cartCount, wishlistCount }) => {
  const [search, setSearch] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSearch, setShowSearch] = useState(false);

  const handleSearchChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearch(val);
    if (val.length > 2) {
      const aiSugs = await getAiSearchSuggestions(val);
      setSuggestions(aiSugs);
    } else {
      setSuggestions([]);
    }
  };

  return (
    <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-md border-b border-gray-100 px-4 py-3">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2">
          <div className="bg-black text-white p-1.5 rounded-lg">
            <i className="fa-solid fa-bolt-lightning text-xl"></i>
          </div>
          <span className="text-2xl font-black tracking-tighter text-black uppercase hidden md:block">
            Blakshall
          </span>
        </Link>

        {/* Desktop Search */}
        <div className="flex-1 max-w-xl relative hidden md:block">
          <div className="relative">
            <input
              type="text"
              placeholder="Search collections..."
              className="w-full bg-gray-100 border-none rounded-full py-2.5 pl-10 pr-4 focus:ring-2 focus:ring-black transition-all"
              value={search}
              onChange={handleSearchChange}
            />
            <i className="fa-solid fa-magnifying-glass absolute left-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
          </div>
          {suggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-2 bg-white shadow-2xl rounded-xl border border-gray-100 p-2 animate-in fade-in slide-in-from-top-2">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-3 mb-1">AI Suggestions</p>
              {suggestions.map((s, idx) => (
                <button key={idx} className="w-full text-left px-3 py-2 hover:bg-gray-50 rounded-lg text-sm transition-colors">
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Icons */}
        <div className="flex items-center gap-3 md:gap-6 text-xl">
          <button className="md:hidden" onClick={() => setShowSearch(!showSearch)}>
            <i className="fa-solid fa-magnifying-glass"></i>
          </button>
          
          <Link to="/admin" className="hover:text-gray-600 transition-colors" title="Admin Panel">
            <i className="fa-solid fa-screwdriver-wrench"></i>
          </Link>

          <Link to="/wishlist" className="relative hover:text-red-500 transition-colors">
            <i className="fa-regular fa-heart"></i>
            {wishlistCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-black text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                {wishlistCount}
              </span>
            )}
          </Link>

          <Link to="/cart" className="relative hover:text-black transition-colors">
            <i className="fa-solid fa-cart-shopping"></i>
            {cartCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-black text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                {cartCount}
              </span>
            )}
          </Link>

          <Link to="/login" className="hidden sm:flex items-center gap-2 text-sm font-bold bg-black text-white px-4 py-2 rounded-full hover:bg-gray-800 transition-all">
            Login
          </Link>
          <button className="sm:hidden text-2xl">
            <i className="fa-solid fa-bars"></i>
          </button>
        </div>
      </div>

      {/* Mobile Search Overlay */}
      {showSearch && (
        <div className="mt-4 md:hidden animate-in slide-in-from-top duration-300">
          <input
            type="text"
            placeholder="Search..."
            className="w-full bg-gray-100 border-none rounded-lg py-3 px-4 focus:ring-2 focus:ring-black"
          />
        </div>
      )}
    </nav>
  );
};

export default Navbar;
