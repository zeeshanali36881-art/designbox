
import React, { useState, useEffect } from 'react';
import { SLIDER_IMAGES } from '../constants.tsx';

const HeroSlider: React.FC = () => {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % SLIDER_IMAGES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative h-[400px] md:h-[600px] overflow-hidden">
      {SLIDER_IMAGES.map((img, idx) => (
        <div
          key={idx}
          className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
            idx === current ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <img src={img} alt={`Slide ${idx}`} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/30 flex items-center justify-center text-white px-6">
            <div className="text-center max-w-2xl animate-in fade-in slide-in-from-bottom-8 duration-700">
              <h1 className="text-4xl md:text-7xl font-black mb-4 uppercase tracking-tighter">
                {idx === 0 ? 'Elevate Your Edge' : idx === 1 ? 'Precision Crafted' : 'The New Noir'}
              </h1>
              <p className="text-sm md:text-xl font-medium opacity-90 mb-8 max-w-lg mx-auto">
                Discover the latest collections designed for performance and timeless style.
              </p>
              <button className="bg-white text-black px-8 py-3 rounded-full font-bold hover:bg-gray-200 transition-all uppercase tracking-widest text-xs md:text-sm">
                Shop Collection
              </button>
            </div>
          </div>
        </div>
      ))}
      
      {/* Dots */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
        {SLIDER_IMAGES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrent(idx)}
            className={`w-10 h-1 rounded-full transition-all ${
              idx === current ? 'bg-white' : 'bg-white/40 hover:bg-white/60'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default HeroSlider;
