
import React from 'react';
import HeroSlider from '../components/HeroSlider';
import CategoryScroll from '../components/CategoryScroll';
import ProductCard from '../components/ProductCard';
import { Product } from '../types';

interface HomeProps {
  products: Product[];
  onAddToCart: (p: Product) => void;
  onAddToWishlist: (p: Product) => void;
  wishlist: string[];
}

const Home: React.FC<HomeProps> = ({ products, onAddToCart, onAddToWishlist, wishlist }) => {
  return (
    <div className="pb-20">
      <HeroSlider />
      <CategoryScroll />
      
      <section className="max-w-7xl mx-auto px-4 mt-12">
        <div className="flex items-end justify-between mb-10">
          <div>
            <span className="text-gray-400 text-xs font-black uppercase tracking-[0.2em]">Featured Release</span>
            <h2 className="text-4xl font-black uppercase tracking-tighter mt-1">New Arrivals</h2>
          </div>
          <div className="flex gap-2">
            <button className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center hover:bg-black hover:text-white transition-all">
              <i className="fa-solid fa-chevron-left"></i>
            </button>
            <button className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center hover:bg-black hover:text-white transition-all">
              <i className="fa-solid fa-chevron-right"></i>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12">
          {products.map(product => (
            <ProductCard 
              key={product.id} 
              product={product} 
              onAddToCart={onAddToCart}
              onAddToWishlist={onAddToWishlist}
              isWishlisted={wishlist.includes(product.id)}
            />
          ))}
        </div>
      </section>

      {/* Brand Ethos */}
      <section className="bg-black text-white py-24 mt-24">
        <div className="max-w-7xl mx-auto px-4 grid md:grid-cols-3 gap-12 text-center">
          <div className="flex flex-col items-center">
            <i className="fa-solid fa-earth-americas text-4xl mb-6 text-gray-500"></i>
            <h3 className="text-xl font-bold uppercase mb-3">Global Shipping</h3>
            <p className="text-gray-400 text-sm leading-relaxed max-w-[250px]">
              Expedited premium shipping to over 150 countries worldwide.
            </p>
          </div>
          <div className="flex flex-col items-center">
            <i className="fa-solid fa-shield-halved text-4xl mb-6 text-gray-500"></i>
            <h3 className="text-xl font-bold uppercase mb-3">2-Year Warranty</h3>
            <p className="text-gray-400 text-sm leading-relaxed max-w-[250px]">
              We stand by the craftsmanship of every Blakshall product.
            </p>
          </div>
          <div className="flex flex-col items-center">
            <i className="fa-solid fa-recycle text-4xl mb-6 text-gray-500"></i>
            <h3 className="text-xl font-bold uppercase mb-3">Eco Luxury</h3>
            <p className="text-gray-400 text-sm leading-relaxed max-w-[250px]">
              100% recycled packaging and carbon-neutral production.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
