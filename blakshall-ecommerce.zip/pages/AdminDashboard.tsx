
import React, { useState } from 'react';
import { Product } from '../types';
import { generateProductDescription } from '../services/gemini';

interface AdminDashboardProps {
  products: Product[];
  onAddProduct: (p: Product) => void;
  onDeleteProduct: (id: string) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ products, onAddProduct, onDeleteProduct }) => {
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '',
    price: 0,
    category: 'Apparel',
    image: 'https://picsum.photos/seed/newproduct/600/800'
  });
  const [isGenerating, setIsGenerating] = useState(false);

  const handleAiDescription = async () => {
    if (!newProduct.name) return;
    setIsGenerating(true);
    const desc = await generateProductDescription(newProduct.name);
    setNewProduct({ ...newProduct, description: desc });
    setIsGenerating(false);
  };

  const handleAdd = () => {
    if (newProduct.name && newProduct.price) {
      onAddProduct({
        ...newProduct as Product,
        id: `p-${Date.now()}`,
        rating: 5.0,
        description: newProduct.description || 'New premium item.'
      });
      setNewProduct({ name: '', price: 0, category: 'Apparel', image: `https://picsum.photos/seed/${Date.now()}/600/800` });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex items-center gap-4 mb-12">
        <h1 className="text-4xl font-black uppercase tracking-tighter">Admin Dashboard</h1>
        <div className="bg-green-100 text-green-700 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest">
          Active
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-12">
        {/* Statistics */}
        <div className="lg:col-span-3 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { label: 'Total Sales', val: '$124,500', icon: 'fa-chart-line' },
            { label: 'Orders', val: '1,240', icon: 'fa-box' },
            { label: 'Customers', val: '890', icon: 'fa-users' },
            { label: 'Traffic', val: '15.4k', icon: 'fa-arrow-trend-up' }
          ].map((stat, i) => (
            <div key={i} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
              <div className="flex justify-between items-center mb-4">
                <i className={`fa-solid ${stat.icon} text-gray-400 text-xl`}></i>
                <span className="text-xs font-bold text-green-500">+12%</span>
              </div>
              <p className="text-gray-400 text-[10px] font-black uppercase tracking-[0.2em] mb-1">{stat.label}</p>
              <h4 className="text-2xl font-black">{stat.val}</h4>
            </div>
          ))}
        </div>

        {/* Add Product Form */}
        <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-xl h-fit">
          <h2 className="text-xl font-black uppercase mb-6 flex items-center gap-2">
            <i className="fa-solid fa-plus-circle"></i> New Product
          </h2>
          <div className="space-y-4">
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 block mb-2">Name</label>
              <input 
                type="text" 
                value={newProduct.name}
                onChange={e => setNewProduct({...newProduct, name: e.target.value})}
                className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 focus:ring-2 focus:ring-black" 
              />
            </div>
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 block mb-2">Price ($)</label>
              <input 
                type="number" 
                value={newProduct.price}
                onChange={e => setNewProduct({...newProduct, price: parseFloat(e.target.value)})}
                className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 focus:ring-2 focus:ring-black" 
              />
            </div>
            <div>
              <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 block mb-2">Category</label>
              <select 
                className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 focus:ring-2 focus:ring-black"
                value={newProduct.category}
                onChange={e => setNewProduct({...newProduct, category: e.target.value})}
              >
                <option>Apparel</option>
                <option>Footwear</option>
                <option>Accessories</option>
                <option>Tech</option>
              </select>
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">Description</label>
                <button 
                  onClick={handleAiDescription}
                  disabled={isGenerating || !newProduct.name}
                  className="text-[10px] font-bold bg-purple-100 text-purple-700 px-2 py-1 rounded hover:bg-purple-200 transition-colors disabled:opacity-50"
                >
                  {isGenerating ? 'Generating...' : 'AI Generate'}
                </button>
              </div>
              <textarea 
                className="w-full bg-gray-50 border-none rounded-xl py-3 px-4 focus:ring-2 focus:ring-black h-24"
                value={newProduct.description || ''}
                onChange={e => setNewProduct({...newProduct, description: e.target.value})}
              ></textarea>
            </div>
            <button 
              onClick={handleAdd}
              className="w-full bg-black text-white py-4 rounded-xl font-bold uppercase tracking-widest text-sm hover:bg-gray-800 transition-all shadow-lg"
            >
              Confirm Product
            </button>
          </div>
        </div>

        {/* Product Table */}
        <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-gray-100 shadow-xl overflow-x-auto">
          <h2 className="text-xl font-black uppercase mb-6 flex items-center gap-2">
            <i className="fa-solid fa-list-ul"></i> Inventory
          </h2>
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-gray-100 text-[10px] font-black uppercase tracking-widest text-gray-400">
                <th className="pb-4">Product</th>
                <th className="pb-4">Category</th>
                <th className="pb-4">Price</th>
                <th className="pb-4">Stock</th>
                <th className="pb-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {products.map(p => (
                <tr key={p.id} className="border-b border-gray-50 last:border-0 hover:bg-gray-50 transition-colors">
                  <td className="py-4">
                    <div className="flex items-center gap-3">
                      <img src={p.image} className="w-10 h-10 rounded-lg object-cover" />
                      <span className="font-bold">{p.name}</span>
                    </div>
                  </td>
                  <td className="py-4 text-gray-500">{p.category}</td>
                  <td className="py-4 font-bold">${p.price}</td>
                  <td className="py-4">
                    <span className="bg-blue-100 text-blue-700 text-[10px] px-2 py-1 rounded-full font-bold">In Stock</span>
                  </td>
                  <td className="py-4 text-right">
                    <button 
                      onClick={() => onDeleteProduct(p.id)}
                      className="text-gray-300 hover:text-red-500 transition-colors p-2"
                    >
                      <i className="fa-solid fa-trash-can"></i>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
