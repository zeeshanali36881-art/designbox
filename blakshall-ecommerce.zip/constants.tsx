
import { Product, Category } from './types';

export const CATEGORIES: Category[] = [
  { id: '1', name: 'Apparel', image: 'https://picsum.photos/seed/apparel/400/400' },
  { id: '2', name: 'Footwear', image: 'https://picsum.photos/seed/shoes/400/400' },
  { id: '3', name: 'Accessories', image: 'https://picsum.photos/seed/acc/400/400' },
  { id: '4', name: 'Tech', image: 'https://picsum.photos/seed/tech/400/400' },
  { id: '5', name: 'Watch', image: 'https://picsum.photos/seed/watch/400/400' },
  { id: '6', name: 'Bags', image: 'https://picsum.photos/seed/bags/400/400' },
  { id: '7', name: 'Luxury', image: 'https://picsum.photos/seed/luxury/400/400' },
  { id: '8', name: 'Limited', image: 'https://picsum.photos/seed/rare/400/400' },
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'p1',
    name: 'Blakshall Noir Jacket',
    price: 299.99,
    category: 'Apparel',
    image: 'https://picsum.photos/seed/jacket1/600/800',
    description: 'A premium midnight black tailored jacket for the modern individual.',
    rating: 4.8
  },
  {
    id: 'p2',
    name: 'Ghost Runner V1',
    price: 189.99,
    category: 'Footwear',
    image: 'https://picsum.photos/seed/shoes1/600/800',
    description: 'High-performance running shoes designed with carbon fiber stability.',
    rating: 4.5
  },
  {
    id: 'p3',
    name: 'Onyx Chrono',
    price: 450.00,
    category: 'Watch',
    image: 'https://picsum.photos/seed/watch1/600/800',
    description: 'A matte black timepiece featuring swiss movement and sapphire glass.',
    rating: 4.9
  },
  {
    id: 'p4',
    name: 'Carbon Backpack',
    price: 120.00,
    category: 'Bags',
    image: 'https://picsum.photos/seed/bag1/600/800',
    description: 'Water-resistant, anti-theft tech backpack for daily commuters.',
    rating: 4.7
  },
  {
    id: 'p5',
    name: 'Sonic Wireless',
    price: 249.99,
    category: 'Tech',
    image: 'https://picsum.photos/seed/tech2/600/800',
    description: 'Active noise-cancelling headphones with immersive soundstage.',
    rating: 4.6
  },
  {
    id: 'p6',
    name: 'Titanium Belt',
    price: 85.00,
    category: 'Accessories',
    image: 'https://picsum.photos/seed/belt1/600/800',
    description: 'Minimalist belt crafted from genuine leather and titanium buckle.',
    rating: 4.4
  }
];

export const SLIDER_IMAGES = [
  'https://picsum.photos/seed/slide1/1920/800',
  'https://picsum.photos/seed/slide2/1920/800',
  'https://picsum.photos/seed/slide3/1920/800'
];
