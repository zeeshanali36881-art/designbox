
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getAiSearchSuggestions(query: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Suggest 3 related premium product categories or terms for a high-end brand named "Blakshall" given the search: "${query}". Format as a simple comma separated list.`,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text?.split(',').map(s => s.trim()) || [];
  } catch (error) {
    console.error("AI Search Error:", error);
    return [];
  }
}

export async function generateProductDescription(productName: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Write a 2-sentence luxury marketing description for a product called "${productName}" from the brand "Blakshall". Focus on quality, exclusivity, and modern aesthetics.`,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text || "";
  } catch (error) {
    console.error("AI Description Error:", error);
    return "";
  }
}
