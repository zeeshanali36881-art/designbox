
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import AdminDashboard from './pages/AdminDashboard';
import { Product, CartItem } from './types';
import { INITIAL_PRODUCTS } from './constants.tsx';

const App: React.FC = () => {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? {...item, quantity: item.quantity + 1} : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const toggleWishlist = (product: Product) => {
    setWishlist(prev => 
      prev.includes(product.id) ? prev.filter(id => id !== product.id) : [...prev, product.id]
    );
  };

  const addProduct = (p: Product) => setProducts([p, ...products]);
  const deleteProduct = (id: string) => setProducts(products.filter(p => p.id !== id));

  return (
    <Router>
      <div className="min-h-screen flex flex-col font-sans">
        <Navbar cartCount={cart.length} wishlistCount={wishlist.length} />
        
        <main className="flex-grow">
          <Routes>
            <Route 
              path="/" 
              element={
                <Home 
                  products={products} 
                  onAddToCart={addToCart} 
                  onAddToWishlist={toggleWishlist}
                  wishlist={wishlist}
                />
              } 
            />
            <Route 
              path="/admin" 
              element={
                <AdminDashboard 
                  products={products} 
                  onAddProduct={addProduct}
                  onDeleteProduct={deleteProduct}
                />
              } 
            />
            <Route 
              path="/cart" 
              element={
                <div className="max-w-2xl mx-auto py-20 px-4 text-center">
                  <i className="fa-solid fa-bag-shopping text-6xl text-gray-200 mb-6"></i>
                  <h1 className="text-3xl font-black uppercase mb-4 tracking-tighter">Your Cart</h1>
                  {cart.length === 0 ? (
                    <p className="text-gray-500">The collection is waiting for you. Add items to see them here.</p>
                  ) : (
                    <div className="space-y-4 text-left">
                      {cart.map(item => (
                        <div key={item.id} className="flex justify-between items-center border-b pb-4">
                          <div>
                            <p className="font-bold">{item.name}</p>
                            <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                          </div>
                          <p className="font-bold">${(item.price * item.quantity).toFixed(2)}</p>
                        </div>
                      ))}
                      <div className="pt-4 flex justify-between font-black text-xl">
                        <span>Total</span>
                        <span>${cart.reduce((acc, i) => acc + (i.price * i.quantity), 0).toFixed(2)}</span>
                      </div>
                      <button className="w-full bg-black text-white py-4 rounded-xl font-bold uppercase tracking-widest mt-6">
                        Checkout Now
                      </button>
                    </div>
                  )}
                </div>
              } 
            />
            <Route path="/wishlist" element={
              <div className="max-w-7xl mx-auto py-20 px-4">
                <h1 className="text-4xl font-black uppercase mb-12 tracking-tighter">My Wishlist</h1>
                {wishlist.length === 0 ? (
                  <div className="text-center py-20 bg-gray-50 rounded-3xl">
                     <i className="fa-regular fa-heart text-6xl text-gray-200 mb-4"></i>
                     <p className="text-gray-400 font-bold uppercase tracking-widest text-sm">Nothing saved yet</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {products.filter(p => wishlist.includes(p.id)).map(p => (
                      <div key={p.id} className="flex gap-4 items-center bg-white p-4 rounded-2xl shadow-sm">
                        <img src={p.image} className="w-20 h-20 object-cover rounded-xl" />
                        <div>
                          <p className="font-bold">{p.name}</p>
                          <p className="text-sm font-black">${p.price}</p>
                          <button onClick={() => toggleWishlist(p)} className="text-[10px] text-red-500 font-bold uppercase mt-2">Remove</button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            } />
            <Route path="/login" element={
              <div className="max-w-md mx-auto py-24 px-4">
                <div className="bg-white p-10 rounded-3xl shadow-2xl border border-gray-100">
                  <h1 className="text-3xl font-black uppercase mb-8 tracking-tighter text-center">Welcome Back</h1>
                  <div className="space-y-6">
                    <input placeholder="Email" className="w-full bg-gray-50 border-none rounded-xl py-4 px-6 focus:ring-2 focus:ring-black" />
                    <input type="password" placeholder="Password" className="w-full bg-gray-50 border-none rounded-xl py-4 px-6 focus:ring-2 focus:ring-black" />
                    <button className="w-full bg-black text-white py-4 rounded-xl font-bold uppercase tracking-widest hover:bg-gray-800 transition-all">Sign In</button>
                    <div className="flex items-center gap-4 text-gray-300">
                      <div className="h-[1px] flex-grow bg-gray-200"></div>
                      <span className="text-[10px] font-bold uppercase tracking-widest">Or</span>
                      <div className="h-[1px] flex-grow bg-gray-200"></div>
                    </div>
                    <button className="w-full bg-gray-100 text-black py-4 rounded-xl font-bold uppercase tracking-widest text-sm hover:bg-gray-200 transition-all">Create Account</button>
                  </div>
                </div>
              </div>
            } />
          </Routes>
        </main>

        <footer className="bg-white border-t border-gray-100 py-12">
          <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-12 text-center md:text-left">
            <div>
              <h5 className="font-black text-xs uppercase tracking-widest mb-6">Collections</h5>
              <ul className="space-y-3 text-sm text-gray-500 font-medium">
                <li><a href="#" className="hover:text-black">New Arrivals</a></li>
                <li><a href="#" className="hover:text-black">Best Sellers</a></li>
                <li><a href="#" className="hover:text-black">Sale</a></li>
                <li><a href="#" className="hover:text-black">Exclusive</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-black text-xs uppercase tracking-widest mb-6">Company</h5>
              <ul className="space-y-3 text-sm text-gray-500 font-medium">
                <li><a href="#" className="hover:text-black">About Us</a></li>
                <li><a href="#" className="hover:text-black">Sustainability</a></li>
                <li><a href="#" className="hover:text-black">Careers</a></li>
                <li><a href="#" className="hover:text-black">Press</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-black text-xs uppercase tracking-widest mb-6">Support</h5>
              <ul className="space-y-3 text-sm text-gray-500 font-medium">
                <li><a href="#" className="hover:text-black">Contact</a></li>
                <li><a href="#" className="hover:text-black">Shipping</a></li>
                <li><a href="#" className="hover:text-black">Returns</a></li>
                <li><a href="#" className="hover:text-black">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-black text-xs uppercase tracking-widest mb-6">Join The Club</h5>
              <p className="text-xs text-gray-400 mb-4 leading-relaxed">Sign up for early access to limited releases.</p>
              <div className="flex">
                <input className="bg-gray-100 border-none rounded-l-lg py-2 px-4 text-sm w-full focus:ring-0" placeholder="Email" />
                <button className="bg-black text-white px-4 py-2 rounded-r-lg text-xs font-bold uppercase">Join</button>
              </div>
            </div>
          </div>
          <div className="max-w-7xl mx-auto px-4 mt-12 pt-8 border-t border-gray-50 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-[10px] font-black uppercase text-gray-300 tracking-widest">&copy; 2024 Blakshall Premium Group.</p>
            <div className="flex gap-6 text-gray-400 text-lg">
              <i className="fa-brands fa-instagram hover:text-black cursor-pointer"></i>
              <i className="fa-brands fa-x-twitter hover:text-black cursor-pointer"></i>
              <i className="fa-brands fa-tiktok hover:text-black cursor-pointer"></i>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
};

export default App;
